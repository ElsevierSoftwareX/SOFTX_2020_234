Lcss_adapter_consolle v1.0 for Windows

INSTALLATION:
1) install the USB drivers you can find in "CDM21228_Setup.zip" by following the instructions on the FTDI drivers installation guides
2) Unzip the "lcss_adapter_consolle.zip"
3) Run the file "lcss_adapter_consolle.exe"